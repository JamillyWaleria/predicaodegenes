/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import javax.swing.JFrame;
public abstract class Constantes {

    public static JFrame janela;
    public static char[] alfabeto = {'A', 'T', 'G', 'C'};
    public static boolean executando;

}
